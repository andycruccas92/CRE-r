Creative Commons Attribution-ShareAlike 4.0 International Public License

You are free to:
- Share — copy and redistribute the material in any medium or format
- Adapt — remix, transform, and build upon the material for any purpose, even commercially.

Under the following terms:
- Attribution — You must give appropriate credit.
- ShareAlike — If you remix, transform, or build upon the material, you must distribute your contributions under the same license.

Full license: https://creativecommons.org/licenses/by-sa/4.0/
